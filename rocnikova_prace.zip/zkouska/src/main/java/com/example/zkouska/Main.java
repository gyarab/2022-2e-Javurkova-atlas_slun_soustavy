package com.example.zkouska;

import javafx.fxml.Initializable;
import javafx.geometry.Point3D;
import javafx.scene.Node;
import javafx.scene.image.Image;
import javafx.scene.paint.PhongMaterial;
import javafx.scene.transform.Translate;

import java.net.URL;
import java.util.ResourceBundle;

public class Main implements Initializable {

    @Override
    public void initialize(URL url, ResourceBundle resourceBundle) {

    }
}
